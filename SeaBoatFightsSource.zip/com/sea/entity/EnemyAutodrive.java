package com.sea.entity;
public interface EnemyAutodrive
{
	public abstract void drive(Entity...e);
}